import React, { useState } from 'react';
import CurrentDateComponent from './Component/CurrentDateComponent';
import './App.css';

function App() {
  const [toDos, setToDos] = useState([]);
  const [toDo, setToDo] = useState('');

  const handleAddToDo = () => {
    if (toDo.trim() !== '') {
      setToDos([...toDos, { id: Date.now(), text: toDo, status: false }]);
      setToDo(''); // Clear input after adding todo
    }
  };

  const handleToggleStatus = (id) => {
    const updatedToDos = toDos.map((todo) =>
      todo.id === id ? { ...todo, status: !todo.status } : todo
    );
    setToDos(updatedToDos);
  };

  const hasPendingTasks = toDos.some((todo) => !todo.status);
  const hasCompletedTasks = toDos.some((todo) => todo.status);

  return (
    <div className="app">
      <div className="mainHeading">
        <h2>ToDo List</h2>
      </div>
      <div className="subHeading">
        <br />
        <CurrentDateComponent />
      </div>
      <div className="input">
        <input
          value={toDo}
          onChange={(e) => setToDo(e.target.value)}
          type="text"
          placeholder="🖊️ Add item..."
        />
        <i onClick={handleAddToDo} className="fas fa-plus"></i>
      </div>
      <div className='pendingdiv'>
        {hasPendingTasks && (
          <div className="todoheader">
            <h2>Pending Task</h2>
          </div>
        )}
        <div className="todos">
          {toDos
            .filter((obj) => !obj.status) // Display only items with status=false
            .map((obj) => (
              <div className="maindiv" key={obj.id}>
                <div className="todo">
                  <div className="left">
                    <input
                      onChange={() => handleToggleStatus(obj.id)}
                      checked={obj.status}
                      type="checkbox"
                      name=""
                      id=""
                    />
                    <p>{obj.text}</p>
                  </div>
                </div>
              </div>
            ))}
        </div>
      </div>
      <div className='completeddiv'>
        {hasCompletedTasks && (
          <div className="todoheader">
            <h2>Completed Task</h2>
          </div>
        )}
        {toDos.map((obj) => {
          if (obj.status) {
            return <p className='completeditems'><i className="fa-solid fa-thumbs-up"></i> {obj.text}</p>;
          }
          return null; // Return null for items with status=false (handled in previous map)
        })}
      </div>
    </div>
  );
}

export default App;
